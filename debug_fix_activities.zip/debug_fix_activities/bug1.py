# Expected Output: Print numbers from 1 to 5
i = 1
while i <= 5:
    print(i)

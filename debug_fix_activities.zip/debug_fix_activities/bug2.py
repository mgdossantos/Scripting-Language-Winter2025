# Expected Output: Print even numbers between 1 and 10
for i in range(1, 10):  
    if i % 2 == 0:
        print(i)
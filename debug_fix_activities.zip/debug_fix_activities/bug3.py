# Expected Output: Sum all numbers from 1 to 5
total = 0
for i in range(1, 6):
total += i  
print("Total:", total)
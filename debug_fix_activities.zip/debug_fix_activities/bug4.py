# Expected Output: Print "Python is fun!" 5 times
count = 0
while count < 5:
    print("Python is fun!")
    count = count - 1  
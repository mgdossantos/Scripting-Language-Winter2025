# Expected Output: Print numbers from 5 to 1 in reverse
for i in range(5, 1):
    print(i)
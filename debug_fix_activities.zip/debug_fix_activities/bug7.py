# Expected Output: Keep asking until the user enters a positive number
number = -1
while number < 0:
    input("Enter a positive number: ")
print("Thank you!")